<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
// Route::post('checklog', function(){
//     dd('dawdaw');
// });
// Route::group(['middleware' => 'userpin'], function() {
    // Route::post('/checklog_store', [\App\Http\Controllers\Api\ApiPresensiController::class], 'checklog_store');
// });
    
    
    Route::post('login', [\App\Http\Controllers\Api\AuthController::class, 'login']);
    
    
    Route::group(['middleware' => ['auth:sanctum']], function () {
        Route::post('logout', [\App\Http\Controllers\Api\AuthController::class, 'logout']);
        Route::post('/checklog', [\App\Http\Controllers\Api\ApiPresensiController::class, 'checklog_store']);
        Route::post('/test', function(){
            return view('test');
        });
});